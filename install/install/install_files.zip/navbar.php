<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="home">Biblioteka</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
        <a class="nav-link" href="home">Strona główna / Dodaj książkę</a>
      </li>
      <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'view_books.php' ? 'active' : ''; ?>">
        <a class="nav-link" href="view">Moja Biblioteka</a>
      </li>
      <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'reading_books.php' ? 'active' : ''; ?>">
        <a class="nav-link" href="read">Przeczytane Książki</a>
      </li>
      <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'notes.php' ? 'active' : ''; ?>">
        <a class="nav-link" href="notes">Oceny i notatki</a>
      </li>
      <!-- Dodaj kolejne elementy menu tutaj -->
    </ul>
  </div>
</nav>